define( [ './threex.text'
	, './fonts/droid/droid_serif_regular.typeface'
	, './fonts/gentilis_bold.typeface'
	, './fonts/gentilis_regular.typeface'
	, './fonts/optimer_bold.typeface'
	, './fonts/optimer_regular.typeface'
	, './fonts/helvetiker_bold.typeface'
	, './fonts/helvetiker_regular.typeface'
	, './fonts/droid/droid_sans_regular.typeface'
	, './fonts/droid/droid_sans_bold.typeface'
	, './fonts/droid/droid_serif_bold.typeface'
	], function(){
})
